import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class academicleague extends PApplet {

gui maingui;

Questions_Array mainqs;

public void setup() {
  
  
  maingui = new gui("data/gui.json");
  thread("loadQuestions");
  
  textFont(createFont(maingui.fontLoc, height));
}

public void draw() {
  background(maingui.background);
  maingui.renderTopMargin();
  
  fill(maingui.textC2);
  int tS = height / 30;
  textSize(tS);
  try {
    text(mainqs.Qs.get(maingui.questionIndex).displayDesc, maingui.m, maingui.mHeight + maingui.m, width - (2 * maingui.m), height);
    if (mousePressed && mouseY > height / 2) maingui.showAnswer = true;
    if (maingui.showAnswer) {
      String answer = mainqs.Qs.get(maingui.questionIndex).title;
      if (mouseX > width - 100 && mouseY > height - maingui.mHeight && mouseX > width - maingui.mHeight) {
        fill(0, 255, 255);
      }
      text(answer, (width - textWidth(answer)) / 2, height * (3.0f / 4) + (tS / 2));
      if (mousePressed && mouseY > height - maingui.mHeight && mouseX > width - maingui.mHeight) link(mainqs.Qs.get(maingui.questionIndex).URL);
      image(maingui.utils[0], width - maingui.mHeight, height - maingui.mHeight, maingui.mHeight, maingui.mHeight);
    } else {
      String sanswer = "Show Answer";
      text(sanswer, (width - textWidth(sanswer)) / 2, height * (3.0f / 4) + (tS / 2));
      if (mouseY > height / 2) {
        fill(255, 100);
        rect(maingui.m, height / 2 + maingui.m, width - (2 * maingui.m), height / 2 - (2 * maingui.m), maingui.m);
      }
    }
  } catch (Exception e) {
    text("Loading Data", maingui.m, maingui.mHeight + maingui.m, width - (2 * maingui.m), height);
  }
  
  try {
    if (maingui.finishedLoadingPreliminaryQuestions && !maingui.loadingnewQ && maingui.questionIndex + maingui.deltaNumberOfQuestions > mainqs.Qs.size() - 1) {
      thread("newQ");
    }
  } catch (Exception e) {}
}

public void loadQuestions() {
  mainqs = new Questions_Array();
  maingui.finishedLoadingPreliminaryQuestions = true;
}

public void newQ() {
  maingui.loadingnewQ = true;
  mainqs.Qs.add(new question());
  maingui.loadingnewQ = false;
}
class gui {
  String fontLoc;
  int textC;
  int textC2;
  int background;
  
  int mHeight;
  int mColor;
  
  int m;
  boolean finishedLoadingPreliminaryQuestions = false;
  boolean loadingnewQ = false;
  
  boolean showAnswer = false;
  
  PImage[] arrows;
  PImage[] utils;
  
  int questionIndex = 0;
  String questionsLocation = "https://en.wikipedia.org/api/rest_v1/page/random/summary";
  int startNumberOfQuestions = 15;
  int deltaNumberOfQuestions = 5;
  
  gui (String l) {
    JSONObject tempGUIData = loadJSONObject(l);
    fontLoc = tempGUIData.getString("font_location");
    int r = tempGUIData.getJSONArray("background_color").getInt(0);
    int g = tempGUIData.getJSONArray("background_color").getInt(1);
    int b = tempGUIData.getJSONArray("background_color").getInt(2);
    background = color(r, g, b);
    
    mHeight = height * tempGUIData.getInt("top_margin_height_percentage") / 100;
    r = tempGUIData.getJSONArray("top_margin_color").getInt(0);
    g = tempGUIData.getJSONArray("top_margin_color").getInt(1);
    b = tempGUIData.getJSONArray("top_margin_color").getInt(2);
    mColor = color(r, g, b);
    
    m = tempGUIData.getInt("margin");
    
    arrows = new PImage[2];
    arrows[0] = loadImage(tempGUIData.getJSONArray("arrow_locations").getString(0));
    arrows[1] = loadImage(tempGUIData.getJSONArray("arrow_locations").getString(1));
    utils = new PImage[2];
    utils[0] = loadImage(tempGUIData.getJSONArray("utilities").getString(0));
    utils[1] = loadImage(tempGUIData.getJSONArray("utilities").getString(1));
    
    r = tempGUIData.getJSONArray("text_color").getInt(0);
    g = tempGUIData.getJSONArray("text_color").getInt(1);
    b = tempGUIData.getJSONArray("text_color").getInt(2);
    textC = color(r, g, b);
    
    r = tempGUIData.getJSONArray("text_color2").getInt(0);
    g = tempGUIData.getJSONArray("text_color2").getInt(1);
    b = tempGUIData.getJSONArray("text_color2").getInt(2);
    textC2 = color(r, g, b);
  }
  
  public void renderTopMargin() {
    noStroke();
    fill(mColor);
    rect(0, 0, width, mHeight);
    
    noFill();
    stroke(background);
    rect(m, m, mHeight - (2 * m), mHeight - (2 * m));
    image(arrows[0], m, m, mHeight - (2 * m), mHeight - (2 * m));
    rect(mHeight + m, m, mHeight - (2 * m), mHeight - (2 * m));
    image(arrows[1], mHeight, m, mHeight - (2 * m), mHeight - (2 * m));
    rect(width - mHeight + m, m, mHeight - (2 * m), mHeight - (2 * m));
    image(utils[1], width - mHeight, m, mHeight - (2 * m), mHeight - (2 * m));
    
    fill(textC);
    textSize(mHeight - (2 * m));
    String displayText;
    try { displayText = questionIndex + 1 + " of " + mainqs.Qs.size(); } catch (Exception e) { displayText = "#" + (questionIndex + 1); }
    text(displayText, (2 * mHeight) + m, mHeight - m);
  }
}
class question {
  String URL;
  String title;
  String description;
  String displayDesc;
  
  question () {
    do {
      JSONObject tempQuestionData = loadJSONObject(maingui.questionsLocation);
      title = tempQuestionData.getString("title");
      URL = tempQuestionData.getJSONObject("content_urls").getJSONObject("desktop").getString("page");
      description = tempQuestionData.getString("extract");
    } while (description.length() < 200); //Arbitrary cutoff of at least 200 characters when retrieving data.
    displayDesc = description;
    String lowTitle = title;
    displayDesc = displayDesc.toLowerCase();
    lowTitle = lowTitle.toLowerCase();
    lowTitle = split(lowTitle, ",")[0];
    lowTitle = split(lowTitle, " (")[0];
    displayDesc = join(split(displayDesc, lowTitle), "#####");
  }
  
  public JSONObject getJSONVersion() {
    JSONObject dat = new JSONObject();
    dat.setString("URL", URL);
    dat.setString("title", title);
    dat.setString("description", description);
    return dat;
  }
}
class Questions_Array {
  ArrayList<question> Qs;
  
  Questions_Array () {
    Qs = new ArrayList<question>(maingui.startNumberOfQuestions);
    
    for (int i = 0; i < maingui.startNumberOfQuestions; i++) {
      Qs.add(new question());
    }
  }
}

public void saveSessionData(File selection) {
  if (selection == null) {
    println("Saving session Data was canceled.");
  } else {
    String target = selection.getAbsolutePath();
    if (!target.substring(target.length() - 5).equals(".json")) target += ".json";
    JSONArray output = new JSONArray();
    for (int i = 0; i < mainqs.Qs.size(); i++) {
      output.setJSONObject(i, mainqs.Qs.get(i).getJSONVersion());
    }
    saveJSONArray(output, target);
  }
}
public void mousePressed() {
  try {
    if (mouseX > maingui.m && mouseY > maingui.m && mouseX < maingui.m + (maingui.mHeight - (2 * maingui.m)) && mouseY < maingui.m + (maingui.mHeight - (2 * maingui.m))) {
      maingui.questionIndex = max(maingui.questionIndex - 1, 0);
      maingui.showAnswer = false;
    } else if (mouseX > maingui.m + maingui.mHeight && mouseY > maingui.m && mouseX < maingui.m + maingui.mHeight + (maingui.mHeight - (2 * maingui.m)) && mouseY < maingui.m + (maingui.mHeight - (2 * maingui.m))) {
      maingui.questionIndex = min(maingui.questionIndex + 1, mainqs.Qs.size() - 1);
      maingui.showAnswer = false;
    } else if (mouseX > width - maingui.mHeight + maingui.m && mouseY > maingui.m && mouseX < width - maingui.m && mouseY < maingui.mHeight - maingui.m) {
      selectOutput("Select target location for JSON Data", "saveSessionData");
    }
  } catch (Exception e) {}
}
  public void settings() {  size(1200, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "academicleague" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
